"""Isolated non-production Direct Reading V2 application service.

The deterministic engine owns every chart fact.  The language model receives
only the user's bounded question and a small, versioned rendering of the
already-cast base, mutual, moving-line and changed hexagrams.  No discernment
or structured-intake field is a generation prerequisite.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import unicodedata
from collections.abc import Callable
from datetime import datetime
from time import perf_counter
from typing import Any, Literal, Protocol
from uuid import uuid4
from zoneinfo import ZoneInfo

from openai import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    OpenAI,
    RateLimitError,
)
from pydantic import BaseModel, ConfigDict, Field, StrictInt, ValidationError, field_validator

from abalo_iching.application.interpretation_packet_v1 import (
    InterpretationPacketV1,
    build_interpretation_packet_v1,
)
from abalo_iching.application.sites_question_context_v1 import normalize_question_text
from abalo_iching.interpretation.knowledge import load_canonical_texts
from abalo_iching.meihua import MeihuaInput, cast_meihua
from abalo_iching.meihua.exceptions import InputValidationError
from abalo_iching.meihua.hexagrams import load_hexagrams
from abalo_iching.meihua.models import MeihuaChart


CONTRACT_VERSION = "SITES_DIRECT_READING_V2_NONPROD_V1"
PROMPT_VERSION = "GUANXIANG_DIRECT_READING_PROMPT_V1_1"
MODEL = "gpt-5.6-sol"
REASONING_EFFORT = "high"
VERBOSITY = "medium"
MAX_OUTPUT_TOKENS = 4_000
MIN_COMPLETE_CHARS = 800
MAX_COMPLETE_CHARS = 12_000
_REQUEST_ID_PATTERN = re.compile(r"^drv2-[a-f0-9]{16,64}$", re.ASCII)

SYSTEM_PROMPT = (
    "你是观象的易经解卦者。程序已经完成确定性排盘，不得重新排盘。请直接回答用户所问之事，不要要求补充辨识信息。"
    "先给明确但有边界的判断，再依次说明本卦、互卦、动爻、变卦怎样共同支持这个判断，最后给出适合做什么、不适合做什么、"
    "反向风险和改变判断所需的现实信号。每一层都必须连接所问，区分卦象事实与现实推断，不得虚构事实、第三方动机、具体日期或必然结果。"
    "使用自然、有传统文化气息的中文；完整优先，避免在不同章节重复同一解释，全文控制在约1800至2600汉字内。"
)
USER_TEMPLATE = (
    "本次所问：{question}\n\n"
    "以下卦盘由程序确定，请直接解释，不要重新计算：\n{chart_packet}\n\n"
    "本次没有额外辨识或现实背景。请仍然给出完整、紧扣所问的解卦。"
)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class DirectReadingRequest(StrictModel):
    question_text: str
    numbers: tuple[StrictInt, StrictInt, StrictInt]

    @field_validator("question_text")
    @classmethod
    def normalize_question(cls, value: object) -> str:
        normalized = normalize_question_text(value)
        if any(unicodedata.category(char) == "Cf" for char in normalized):
            raise ValueError("question_text contains format characters")
        return normalized

    @field_validator("numbers")
    @classmethod
    def validate_numbers(
        cls, value: tuple[int, int, int]
    ) -> tuple[int, int, int]:
        if any(isinstance(item, bool) or not 1 <= item <= 999 for item in value):
            raise ValueError("numbers must be strict integers between 1 and 999")
        return value


class DirectReadingUsage(StrictModel):
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    total_tokens: int = Field(ge=0)


class DirectReadingProviderResult(StrictModel):
    output_text: str
    api_status: str | None
    incomplete_details: object | None
    response_id: str | None
    model: str
    usage: DirectReadingUsage
    latency_ms: int = Field(ge=0)


class DirectReadingProvider(Protocol):
    def generate(self, *, system_prompt: str, user_prompt: str) -> DirectReadingProviderResult: ...


class DirectReadingProviderFailure(RuntimeError):
    """Safe provider error carrying only a stable, non-sensitive code."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class DirectReadingHexagramFact(StrictModel):
    role: Literal["BASE", "MUTUAL", "CHANGED"]
    king_wen_number: int = Field(ge=1, le=64)
    name: str
    upper_trigram: str
    lower_trigram: str


class DirectReadingLineFact(StrictModel):
    position: int = Field(ge=1, le=6)
    name: str
    canonical_line_text: str
    canonical_data_version: str


class DirectReadingChartFacts(StrictModel):
    base_hexagram: DirectReadingHexagramFact
    mutual_hexagram: DirectReadingHexagramFact
    changed_hexagram: DirectReadingHexagramFact
    moving_line: DirectReadingLineFact
    rule_version: str
    engine_version: str


class DirectReadingContent(StrictModel):
    version: Literal[CONTRACT_VERSION] = CONTRACT_VERSION
    content_format: Literal["MARKDOWN"] = "MARKDOWN"
    text: str
    chart_facts: DirectReadingChartFacts
    validation_status: Literal["PASSED"] = "PASSED"


class DirectReadingAudit(StrictModel):
    request_id: str
    request_sha256: str
    question_sha256: str
    chart_sha256: str
    prompt_sha256: str
    prompt_version: Literal[PROMPT_VERSION] = PROMPT_VERSION
    model: str
    response_id: str | None = None
    usage: DirectReadingUsage | None = None
    latency_ms: int | None = None
    generated_at: str


class DirectReadingResponse(StrictModel):
    contract_version: Literal[CONTRACT_VERSION] = CONTRACT_VERSION
    status: Literal[
        "SUCCESS",
        "INVALID_REQUEST",
        "ENGINE_ERROR",
        "UNAVAILABLE",
        "INCOMPLETE",
        "BLOCKED_OUTPUT",
    ]
    direct_reading: DirectReadingContent | None = None
    audit: DirectReadingAudit
    error_code: str | None = None
    error_message: str | None = None
    validation_errors: list[str] = Field(default_factory=list)
    retryable: bool = False
    failure_stage: Literal["INPUT", "ENGINE", "PROVIDER", "COMPLETENESS", "CONTENT"] | None = None


class OpenAIDirectReadingProvider:
    """One Responses API call, with the exact configuration validated in research."""

    def __init__(
        self,
        *,
        client_factory: Callable[..., Any] = OpenAI,
        timeout_seconds: float = 120.0,
    ) -> None:
        self._client_factory = client_factory
        self._timeout_seconds = timeout_seconds

    def generate(self, *, system_prompt: str, user_prompt: str) -> DirectReadingProviderResult:
        if not os.getenv("OPENAI_API_KEY"):
            raise DirectReadingProviderFailure("PROVIDER_CONFIGURATION")
        started = perf_counter()
        try:
            client = self._client_factory(timeout=self._timeout_seconds, max_retries=0)
            response = client.responses.create(
                model=MODEL,
                input=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                reasoning={"effort": REASONING_EFFORT},
                text={"verbosity": VERBOSITY},
                store=False,
                tools=[],
                max_output_tokens=MAX_OUTPUT_TOKENS,
            )
        except APITimeoutError as exc:
            raise DirectReadingProviderFailure("PROVIDER_TIMEOUT") from exc
        except RateLimitError as exc:
            raise DirectReadingProviderFailure("PROVIDER_RATE_LIMIT") from exc
        except AuthenticationError as exc:
            raise DirectReadingProviderFailure("PROVIDER_AUTHENTICATION") from exc
        except APIConnectionError as exc:
            raise DirectReadingProviderFailure("PROVIDER_CONNECTION") from exc
        except APIStatusError as exc:
            del exc
            raise DirectReadingProviderFailure("PROVIDER_SERVICE_ERROR") from None
        except Exception as exc:  # pragma: no cover - defensive SDK boundary
            raise DirectReadingProviderFailure("PROVIDER_UNAVAILABLE") from exc

        usage = getattr(response, "usage", None)
        if usage is None:
            raise DirectReadingProviderFailure("PROVIDER_MALFORMED_RESPONSE")
        input_tokens = int(getattr(usage, "input_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
        total_tokens = int(getattr(usage, "total_tokens", input_tokens + output_tokens) or 0)
        details = getattr(response, "incomplete_details", None)
        if hasattr(details, "model_dump"):
            details = details.model_dump(mode="json")
        return DirectReadingProviderResult(
            output_text=str(getattr(response, "output_text", "") or ""),
            api_status=getattr(response, "status", None),
            incomplete_details=details,
            response_id=getattr(response, "id", None),
            model=str(getattr(response, "model", MODEL) or MODEL),
            usage=DirectReadingUsage(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=total_tokens,
            ),
            latency_ms=int((perf_counter() - started) * 1_000),
        )


def _sha_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def _canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _line_display_name(chart: MeihuaChart) -> str:
    yin_yang = "九" if chart.base_hexagram.lines_bottom_up[chart.moving_line - 1] else "六"
    if chart.moving_line == 1:
        return f"初{yin_yang}"
    if chart.moving_line == 6:
        return f"上{yin_yang}"
    return f"{yin_yang}{'一二三四五六'[chart.moving_line - 1]}"


def _chart_facts(chart: MeihuaChart, packet: InterpretationPacketV1) -> DirectReadingChartFacts:
    canonical_version = packet.sources[1].source_version

    def hexagram(role: Literal["BASE", "MUTUAL", "CHANGED"], value: Any) -> DirectReadingHexagramFact:
        return DirectReadingHexagramFact(
            role=role,
            king_wen_number=value.king_wen_number,
            name=value.full_name_zh,
            upper_trigram=value.upper_trigram.name_zh,
            lower_trigram=value.lower_trigram.name_zh,
        )

    return DirectReadingChartFacts(
        base_hexagram=hexagram("BASE", chart.base_hexagram),
        mutual_hexagram=hexagram("MUTUAL", chart.mutual_hexagram),
        changed_hexagram=hexagram("CHANGED", chart.changed_hexagram),
        moving_line=DirectReadingLineFact(
            position=chart.moving_line,
            name=_line_display_name(chart),
            canonical_line_text=packet.moving_line.canonical_line_text,
            canonical_data_version=canonical_version,
        ),
        rule_version=chart.versions.rule_version,
        engine_version=chart.versions.engine_version,
    )


def render_chart_packet(facts: DirectReadingChartFacts) -> str:
    """Render exactly the four-line chart packet used by the successful study."""
    base = facts.base_hexagram
    mutual = facts.mutual_hexagram
    changed = facts.changed_hexagram
    moving = facts.moving_line
    return "\n".join(
        [
            f"本卦：第{base.king_wen_number}卦 {base.name}（上卦{base.upper_trigram}，下卦{base.lower_trigram}）",
            f"互卦：第{mutual.king_wen_number}卦 {mutual.name}",
            f"动爻：{moving.name}，爻辞：{moving.canonical_line_text}",
            f"变卦：第{changed.king_wen_number}卦 {changed.name}（上卦{changed.upper_trigram}，下卦{changed.lower_trigram}）",
        ]
    )


def build_direct_reading_prompts(question_text: str, facts: DirectReadingChartFacts) -> tuple[str, str]:
    return SYSTEM_PROMPT, USER_TEMPLATE.format(
        question=question_text,
        chart_packet=render_chart_packet(facts),
    )


_DATE_PATTERNS = (
    re.compile(r"(?<!\d)(?:19|20)\d{2}\s*[-/.]\s*\d{1,2}\s*[-/.]\s*\d{1,2}(?!\d)"),
    re.compile(r"(?<!\d)(?:19|20)\d{2}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日"),
    re.compile(r"(?<!\d)\d{1,2}\s*月\s*\d{1,2}\s*日"),
    re.compile(r"(?<!\d)\d{1,2}\s*[-/.]\s*\d{1,2}(?!\d)"),
    re.compile(r"[二〇零一三四五六七八九]{4}年[一二三四五六七八九十]{1,3}月[一二三四五六七八九十]{1,3}日"),
    re.compile(r"(?<!\d)(?:19|20)\d{2}年"),
)
_RELATIVE_TIME_PATTERNS = (
    re.compile(r"(?:今天|明天|后天|大后天|近日|近期|过几天|周末)"),
    re.compile(r"(?:上|本|这|下)周[一二三四五六日天1-7]?"),
    re.compile(r"(?:本|这|下)?(?:月初|月底|上旬|中旬|下旬)|下个月(?:初|中|底|\d{1,2}日)?"),
    re.compile(r"[一二三四五六七八九十两\d]{1,3}个?(?:天|周|星期|月|季度|年)后"),
)
_ABSOLUTE_PATTERN = re.compile(
    r"一定(?:会|能|能够|可以)|肯定(?:会|能|能够|可以)?(?:成功|失败|实现|发生)?|铁定|绝对会|"
    r"必然(?:会|能够|成功|失败|实现|发生)|注定|"
    r"百分之百|百分百|100\s*%|必成|必败|十拿九稳|板上钉钉|稳赢|绝对(?:成功|失败)|"
    r"保证.{0,10}(?:成功|失败|实现|发生)"
)
_NEGATION_PATTERN = re.compile(r"不|无|非|未|避免|不能|不可|并不|并非|不是|不等于|无法")
_MIND_READING_PATTERN = re.compile(
    r"(?:领导|老板|上司|对方|他|她|伴侣|公司|合伙人|客户|招聘方|HR|hr|面试官|评委|决策者|董事会|同事|家人|父母).{0,12}"
    r"(?:故意|内心|其实想|已经?决定|已决定|在骗|爱你|讨厌你|(?:准备|将要|马上|肯定|必然|一定|会)裁员|一定|必然)"
)
_CONDITIONAL_PATTERN = re.compile(r"可能|或许|若|如果|需要核实|需要确认|不能据卦|无法断定|不代表|未必")
_DANGEROUS_MARKUP = re.compile(
    r"<\s*(?:script|iframe|object|embed|style|svg|math)\b|&lt;\s*(?:script|iframe)|"
    r"javascript\s*:|data\s*:\s*text/html|on(?:error|load|click)\s*=",
    re.IGNORECASE,
)
_ANY_HTML_TAG = re.compile(r"<\s*/?\s*[A-Za-z][^>]{0,200}>|&lt;\s*/?\s*[A-Za-z]", re.IGNORECASE)
_SECRET_PATTERN = re.compile(
    r"\bsk-[A-Za-z0-9_-]{8,}|OPENAI_API_KEY|(?:system|系统)\s*prompt|系统\s*(?:提示词|指令)",
    re.IGNORECASE,
)
_UNAUTHORIZED_CLASSIC = re.compile(
    r"《(?:序卦|彖传?|象传?|系辞(?:上|下)?|道德经|论语|说卦|杂卦)》|彖曰|象曰|"
    r"天行健|穷则变|君子藏器|知止不殆|知之为知之|物生必蒙"
)
_CLASSICAL_SIGNAL = re.compile(r"无咎|无悔|悔亡|吉|凶|亨|贞|貞|利|君子|大人|有攸往|勿用|曰")
_QUOTED_SPAN = re.compile(r"(?:“([^”]{4,160})”|\"([^\"]{4,160})\"|「([^」]{4,160})」|『([^』]{4,160})』|‘([^’]{4,160})’)")
_REALITY_FACT_PATTERN = re.compile(
    r"(?:你已|你已经)(?:在|工作|投入|交往|结婚|准备|负责|担任)|"
    r"你在(?:公司|团队|部门).{0,8}(?:干了|工作了|待了)[一二三四五六七八九十两\d]+年|"
    r"(?:你的)?(?:公司|团队|部门|项目).{0,8}(?:正在|已经|已)(?:重组|裁员|招聘|调整|关闭|亏损|盈利|扩张)|"
    r"你们已经|事实上你"
)
_DATE_JUDGMENT_PATTERN = re.compile(
    r"最佳|最有利|吉日|行动日|就定在|应当|应该|适合|宜在|行动|联系|决定|会有结果|"
    r"会发生|离职|提交|启动|公开|再(?:做|去|联系|行动|决定)"
)
_CANONICAL_VARIANT_TRANSLATION = str.maketrans(
    {
        "渙": "涣",
        "繫": "系",
        "剝": "剥",
        "豐": "丰",
        "見": "见",
        "發": "发",
        "貞": "贞",
    }
)


def _normalized_quote(value: str) -> str:
    normalized = unicodedata.normalize("NFC", value).translate(_CANONICAL_VARIANT_TRANSLATION)
    return re.sub(r"[\s，,。；;：:！!？?‘’“”\"']+", "", normalized)


def _has_unsupported_date(text: str, question_text: str) -> bool:
    normalized_text = unicodedata.normalize("NFKC", text)
    normalized_question = unicodedata.normalize("NFKC", question_text)
    for pattern in _DATE_PATTERNS:
        for match in pattern.finditer(normalized_text):
            token = match.group(0)
            if token not in normalized_question:
                return True
            sentence_start = max(
                normalized_text.rfind(mark, 0, match.start()) for mark in ("。", "！", "？", "\n")
            )
            sentence_end_candidates = [
                position
                for mark in ("。", "！", "？", "\n")
                if (position := normalized_text.find(mark, match.end())) >= 0
            ]
            sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(normalized_text)
            sentence = normalized_text[sentence_start + 1 : sentence_end]
            if _DATE_JUDGMENT_PATTERN.search(sentence):
                return True
    for pattern in _RELATIVE_TIME_PATTERNS:
        for match in pattern.finditer(normalized_text):
            sentence_start = max(
                normalized_text.rfind(mark, 0, match.start()) for mark in ("。", "！", "？", "\n")
            )
            sentence_end_candidates = [
                position
                for mark in ("。", "！", "？", "\n")
                if (position := normalized_text.find(mark, match.end())) >= 0
            ]
            sentence_end = min(sentence_end_candidates) if sentence_end_candidates else len(normalized_text)
            sentence = normalized_text[sentence_start + 1 : sentence_end]
            rhetorical_conditional = bool(re.search(r"若|如果|假如", sentence))
            if (
                match.group(0) not in normalized_question
                and _DATE_JUDGMENT_PATTERN.search(sentence)
                and not rhetorical_conditional
            ):
                return True
            if match.group(0) in normalized_question and _DATE_JUDGMENT_PATTERN.search(sentence):
                return True
    return False


def _has_unqualified_match(pattern: re.Pattern[str], text: str) -> bool:
    for match in pattern.finditer(text):
        prefix = text[max(0, match.start() - 24) : match.start()]
        prefix = re.split(r"[。！？!?；;，,、：:\n]|但是|但|却|然而|可是|不过", prefix)[-1]
        if not _NEGATION_PATTERN.search(prefix):
            return True
    return False


def _has_unqualified_mind_reading(text: str) -> bool:
    for match in _MIND_READING_PATTERN.finditer(text):
        context = text[max(0, match.start() - 24) : match.end()]
        context = re.split(r"[。！？!?；;，,、：:\n]|但是|但|却|然而|可是|不过", context)[-1]
        if not _CONDITIONAL_PATTERN.search(context) and not _NEGATION_PATTERN.search(context):
            return True
    return False


def _has_unqualified_reality_fact(text: str) -> bool:
    for match in _REALITY_FACT_PATTERN.finditer(text):
        sentence_start = max(text.rfind(mark, 0, match.start()) for mark in ("。", "！", "？", "\n"))
        sentence = text[sentence_start + 1 : match.end()]
        if not _CONDITIONAL_PATTERN.search(sentence) and not _NEGATION_PATTERN.search(sentence):
            return True
    return False


def _role_heading_error(text: str, label: str, expected_name: str, expected_number: int) -> bool:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    heading_pattern = re.compile(
        rf"^\s*(?:(?:#{{1,6}}\s*\*{{0,2}})|(?:\*{{2}}))"
        rf"(?:[一二三四五六七八九十0-9]+[、.．]\s*)?{re.escape(label)}"
    )
    headings = [line.strip(" #*\t") for line in lines if heading_pattern.search(line)]
    if not headings or not any(expected_name in line for line in headings):
        return True
    all_names = {item.full_name_zh for item in load_hexagrams()}
    for line in headings:
        present_names = {name for name in all_names if name in line}
        if present_names and present_names != {expected_name}:
            return True
        number_match = re.search(r"第\s*(\d{1,2})\s*卦", line)
        if number_match and int(number_match.group(1)) != expected_number:
            return True
    return False


def _role_statement_error(text: str, label: str, expected_name: str) -> bool:
    names = {item.full_name_zh for item in load_hexagrams()} - {expected_name}
    for name in names:
        direct_pattern = re.compile(
            rf"{re.escape(label)}\s*(?:(?:其实|實際|实际|真正|应当|應當|应该|應該|并非|不是)\s*)?"
            rf"(?:就是|乃|而是|是|为|為|应为|應為|应该是|應該是)\s*(?:第\d{{1,2}}卦\s*)?{re.escape(name)}"
        )
        correction_pattern = re.compile(
            rf"{re.escape(label)}[^。！？!?\n]{{0,20}}(?:而是|实为|實為)\s*(?:第\d{{1,2}}卦\s*)?{re.escape(name)}"
        )
        if direct_pattern.search(text) or correction_pattern.search(text):
            return True
    return False


def _trigram_statement_error(
    text: str,
    label: str,
    expected_upper: str,
    expected_lower: str,
) -> bool:
    pattern = re.compile(
        rf"{re.escape(label)}.{{0,24}}上(?:卦)?\s*(?:是|为|為)?\s*([乾兑離离震巽坎艮坤]).{{0,16}}"
        rf"下(?:卦)?\s*(?:是|为|為)?\s*([乾兑離离震巽坎艮坤])"
    )
    for match in pattern.finditer(text):
        upper = "离" if match.group(1) == "離" else match.group(1)
        lower = "离" if match.group(2) == "離" else match.group(2)
        if upper != expected_upper or lower != expected_lower:
            return True
    return False


def _section_errors(text: str, moving_line_name: str) -> list[str]:
    specifications: list[tuple[str, re.Pattern[str], int]] = [
        ("判断", re.compile(r"^\s*#{1,6}\s*\*{0,2}(?:判断|结论|总断|先断)"), 60),
        ("本卦", re.compile(r"^\s*#{1,6}\s*\*{0,2}(?:[一二三四五六七八九十0-9]+[、.．]\s*)?本卦"), 80),
        ("互卦", re.compile(r"^\s*#{1,6}\s*\*{0,2}(?:[一二三四五六七八九十0-9]+[、.．]\s*)?互卦"), 80),
        ("动爻", re.compile(rf"^\s*#{{1,6}}\s*\*{{0,2}}(?:[一二三四五六七八九十0-9]+[、.．]\s*)?(?:动爻|動爻|{re.escape(moving_line_name)})"), 80),
        ("变卦", re.compile(r"^\s*#{1,6}\s*\*{0,2}(?:[一二三四五六七八九十0-9]+[、.．]\s*)?变卦"), 80),
        ("适合", re.compile(r"^\s*(?:#{1,6}\s*)?\*{0,2}适合(?:做什么|做的是|做的|与不适合)"), 50),
        ("不适合", re.compile(r"^\s*(?:#{1,6}\s*)?\*{0,2}不适合(?:做什么|做的是|做的)"), 50),
        ("反向风险", re.compile(r"^\s*(?:#{1,6}\s*)?\*{0,2}反向风险"), 50),
        ("现实信号", re.compile(r"^\s*(?:#{1,6}\s*)?\*{0,2}.*现实信号"), 50),
    ]
    lines = text.splitlines()
    starts: list[tuple[str, int, int]] = []
    for label, pattern, minimum in specifications:
        index = next((position for position, line in enumerate(lines) if pattern.search(line)), -1)
        if index < 0:
            return ["MISSING_DECISION_BOUNDARY"]
        starts.append((label, index, minimum))
    if [item[1] for item in starts] != sorted(item[1] for item in starts):
        return ["SECTION_ORDER"]
    errors: list[str] = []
    for position, (label, start, minimum) in enumerate(starts):
        later_starts = [item[1] for item in starts[position + 1 :] if item[1] > start]
        end = min(later_starts) if later_starts else len(lines)
        body = "".join(lines[start:end]).strip()
        if len(body) < minimum:
            errors.append(f"SECTION_TOO_SHORT:{label}")
    windows = [text[index : index + 12] for index in range(0, max(0, len(text) - 11), 4)]
    if windows and len(set(windows)) / len(windows) < 0.45:
        errors.append("EXCESSIVE_REPETITION")
    return errors


def _relevant_canonical_corpus(facts: DirectReadingChartFacts) -> tuple[set[str], set[str]]:
    records = load_canonical_texts()
    relevant_numbers = {
        facts.base_hexagram.king_wen_number,
        facts.mutual_hexagram.king_wen_number,
        facts.changed_hexagram.king_wen_number,
    }
    moving_line = _normalized_quote(facts.moving_line.canonical_line_text)
    relevant: set[str] = {moving_line}
    all_texts: set[str] = set()
    for item in records:
        judgment = _normalized_quote(item.canonical_judgment_text)
        all_texts.add(judgment)
        if item.king_wen_number in relevant_numbers:
            relevant.add(judgment)
        for line in item.lines:
            normalized = _normalized_quote(line.canonical_line_text)
            all_texts.add(normalized)
    return relevant, all_texts - relevant


def validate_direct_reading_text(
    text: str,
    *,
    question_text: str,
    facts: DirectReadingChartFacts,
) -> tuple[str, ...]:
    """Return stable error codes; never return or log rejected model text."""
    errors: list[str] = []
    normalized = unicodedata.normalize("NFC", text).strip()
    if not MIN_COMPLETE_CHARS <= len(normalized) <= MAX_COMPLETE_CHARS:
        errors.append("CONTENT_LENGTH")
    required_terms = ("判断", "适合", "不适合", "反向风险", "现实信号")
    if any(term not in normalized for term in required_terms):
        errors.append("MISSING_DECISION_BOUNDARY")
    for label, hexagram in (
        ("本卦", facts.base_hexagram),
        ("互卦", facts.mutual_hexagram),
        ("变卦", facts.changed_hexagram),
    ):
        if _role_heading_error(normalized, label, hexagram.name, hexagram.king_wen_number):
            errors.append(f"{label}_MISMATCH")
            errors.append(f"{label}_MISMATCH:HEADING")
        if _role_statement_error(normalized, label, hexagram.name):
            errors.append(f"{label}_MISMATCH")
            errors.append(f"{label}_MISMATCH:ROLE_STATEMENT")
        if _trigram_statement_error(
            normalized,
            label,
            hexagram.upper_trigram,
            hexagram.lower_trigram,
        ):
            errors.append(f"{label}_MISMATCH")
            errors.append(f"{label}_MISMATCH:TRIGRAM")
    canonical_line = _normalized_quote(facts.moving_line.canonical_line_text)
    if facts.moving_line.name not in normalized or canonical_line not in _normalized_quote(normalized):
        errors.append("MOVING_LINE_MISMATCH")
    line_names = {
        f"{yin_yang}{position}"
        for position in "一二三四五"
        for yin_yang in ("九", "六")
    } | {"初九", "初六", "上九", "上六"}
    other_line_names = line_names - {facts.moving_line.name}
    if any(name in normalized for name in other_line_names):
        errors.append("MOVING_LINE_MISMATCH")
    for line in normalized.splitlines():
        if "动爻" in line or "動爻" in line:
            present = {name for name in line_names if name in line}
            if present and present != {facts.moving_line.name}:
                errors.append("MOVING_LINE_MISMATCH")
                break
    if _has_unsupported_date(normalized, question_text):
        errors.append("UNSUPPORTED_DATE")
    if _has_unqualified_match(_ABSOLUTE_PATTERN, normalized):
        errors.append("INEVITABLE_RESULT")
    if _has_unqualified_mind_reading(normalized):
        errors.append("THIRD_PARTY_MIND_READING")
    if _has_unqualified_reality_fact(normalized):
        errors.append("UNSUPPORTED_REALITY_FACT")
    if _DANGEROUS_MARKUP.search(normalized) or _ANY_HTML_TAG.search(normalized):
        errors.append("DANGEROUS_MARKUP")
    if _SECRET_PATTERN.search(normalized):
        errors.append("SECRET_OR_PROMPT_LEAK")
    if SYSTEM_PROMPT[:32] in normalized:
        errors.append("SECRET_OR_PROMPT_LEAK")
    for title in re.findall(r"《[^》]+》", normalized):
        if title not in {"《易》", "《周易》"}:
            errors.append("UNSUPPORTED_CLASSIC_QUOTE")
            break
    if _UNAUTHORIZED_CLASSIC.search(normalized):
        errors.append("UNSUPPORTED_CLASSIC_QUOTE")
    relevant_canonical, unrelated_canonical = _relevant_canonical_corpus(facts)
    normalized_without_punctuation = _normalized_quote(normalized)
    if any(len(value) >= 4 and value in normalized_without_punctuation for value in unrelated_canonical):
        errors.append("UNSUPPORTED_CLASSIC_QUOTE")
    for match in _QUOTED_SPAN.finditer(normalized):
        raw_quote = next(group for group in match.groups() if group is not None)
        quote = _normalized_quote(raw_quote)
        verified = any(quote in canonical for canonical in relevant_canonical)
        if _CLASSICAL_SIGNAL.search(raw_quote) and not verified:
            errors.append("UNSUPPORTED_CLASSIC_QUOTE")
            break
    for line in normalized.splitlines():
        if "爻辞" not in line and "爻辭" not in line:
            continue
        for match in _QUOTED_SPAN.finditer(line):
            raw_quote = next(group for group in match.groups() if group is not None)
            quote = _normalized_quote(raw_quote)
            if _CLASSICAL_SIGNAL.search(raw_quote) and quote not in canonical_line:
                errors.append("MOVING_LINE_MISMATCH")
                break
    errors.extend(_section_errors(normalized, facts.moving_line.name))
    return tuple(dict.fromkeys(errors))


def _now() -> datetime:
    return datetime.now(ZoneInfo("Asia/Shanghai"))


def _empty_audit(
    *, request_id: str,
    generated_at: datetime,
    request_sha256: str = "",
    question_sha256: str = "",
    chart_sha256: str = "",
    prompt_sha256: str = "",
    provider_result: DirectReadingProviderResult | None = None,
) -> DirectReadingAudit:
    return DirectReadingAudit(
        request_id=request_id,
        request_sha256=request_sha256,
        question_sha256=question_sha256,
        chart_sha256=chart_sha256,
        prompt_sha256=prompt_sha256,
        model=provider_result.model if provider_result else MODEL,
        response_id=provider_result.response_id if provider_result else None,
        usage=provider_result.usage if provider_result else None,
        latency_ms=provider_result.latency_ms if provider_result else None,
        generated_at=generated_at.isoformat(),
    )


def _failure(
    *,
    status: Literal["INVALID_REQUEST", "ENGINE_ERROR", "UNAVAILABLE", "INCOMPLETE", "BLOCKED_OUTPUT"],
    request_id: str,
    generated_at: datetime,
    error_code: str,
    error_message: str,
    request_sha256: str = "",
    question_sha256: str = "",
    chart_sha256: str = "",
    prompt_sha256: str = "",
    provider_result: DirectReadingProviderResult | None = None,
    validation_errors: tuple[str, ...] = (),
) -> dict[str, Any]:
    failure_stage: Literal["INPUT", "ENGINE", "PROVIDER", "COMPLETENESS", "CONTENT"] = {
        "INVALID_REQUEST": "INPUT",
        "ENGINE_ERROR": "ENGINE",
        "UNAVAILABLE": "PROVIDER",
        "INCOMPLETE": "COMPLETENESS",
        "BLOCKED_OUTPUT": "CONTENT",
    }[status]
    return DirectReadingResponse(
        status=status,
        audit=_empty_audit(
            request_id=request_id,
            generated_at=generated_at,
            request_sha256=request_sha256,
            question_sha256=question_sha256,
            chart_sha256=chart_sha256,
            prompt_sha256=prompt_sha256,
            provider_result=provider_result,
        ),
        error_code=error_code,
        error_message=error_message,
        validation_errors=list(validation_errors),
        retryable=status in {"UNAVAILABLE", "INCOMPLETE"},
        failure_stage=failure_stage,
    ).model_dump(mode="json")


def process_direct_reading_v2_request(
    request_payload: object,
    *,
    provider: DirectReadingProvider | None = None,
    clock: Callable[[], datetime] | None = None,
    request_id: str | None = None,
) -> dict[str, Any]:
    """Run the isolated non-production direct-reading chain exactly once."""
    safe_request_id = (
        request_id
        if isinstance(request_id, str) and _REQUEST_ID_PATTERN.fullmatch(request_id)
        else f"drv2-{uuid4().hex}"
    )
    generated_at = (clock or _now)()
    if generated_at.tzinfo is None:
        raise ValueError("clock must return an aware datetime")
    try:
        request = DirectReadingRequest.model_validate(request_payload)
    except (ValidationError, ValueError, TypeError):
        return _failure(
            status="INVALID_REQUEST",
            request_id=safe_request_id,
            generated_at=generated_at,
            error_code="INVALID_REQUEST",
            error_message="问题或三个起卦数不符合要求。",
        )

    request_json = _canonical_json(request.model_dump(mode="json"))
    request_sha256 = _sha_text(request_json)
    question_sha256 = _sha_text(request.question_text)
    try:
        chart = cast_meihua(
            MeihuaInput(
                request.numbers[0],
                request.numbers[1],
                request.numbers[2],
                generated_at,
                "Asia/Shanghai",
                safe_request_id,
            )
        )
        packet = build_interpretation_packet_v1(chart)
        facts = _chart_facts(chart, packet)
    except (InputValidationError, RuntimeError, ValueError, KeyError):
        return _failure(
            status="ENGINE_ERROR",
            request_id=safe_request_id,
            generated_at=generated_at,
            error_code="ENGINE_ERROR",
            error_message="确定性排盘暂时无法完成。",
            request_sha256=request_sha256,
            question_sha256=question_sha256,
        )

    chart_packet = render_chart_packet(facts)
    chart_sha256 = _sha_text(chart_packet)
    system_prompt, user_prompt = build_direct_reading_prompts(request.question_text, facts)
    prompt_sha256 = _sha_text(_canonical_json([system_prompt, user_prompt]))
    try:
        result = (provider or OpenAIDirectReadingProvider()).generate(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
        )
    except DirectReadingProviderFailure as exc:
        return _failure(
            status="UNAVAILABLE",
            request_id=safe_request_id,
            generated_at=generated_at,
            error_code=exc.code,
            error_message="解卦服务暂时不可用，请稍后再试。",
            request_sha256=request_sha256,
            question_sha256=question_sha256,
            chart_sha256=chart_sha256,
            prompt_sha256=prompt_sha256,
        )
    except Exception:
        return _failure(
            status="UNAVAILABLE",
            request_id=safe_request_id,
            generated_at=generated_at,
            error_code="PROVIDER_UNAVAILABLE",
            error_message="解卦服务暂时不可用，请稍后再试。",
            request_sha256=request_sha256,
            question_sha256=question_sha256,
            chart_sha256=chart_sha256,
            prompt_sha256=prompt_sha256,
        )

    output_text = unicodedata.normalize("NFC", result.output_text).strip()
    if (
        result.api_status != "completed"
        or result.incomplete_details is not None
        or not output_text
        or result.usage.output_tokens >= MAX_OUTPUT_TOKENS
    ):
        return _failure(
            status="INCOMPLETE",
            request_id=safe_request_id,
            generated_at=generated_at,
            error_code="INCOMPLETE_OUTPUT",
            error_message="本次解卦没有完整生成，请重新发起。",
            request_sha256=request_sha256,
            question_sha256=question_sha256,
            chart_sha256=chart_sha256,
            prompt_sha256=prompt_sha256,
            provider_result=result,
        )

    validation_errors = validate_direct_reading_text(
        output_text,
        question_text=request.question_text,
        facts=facts,
    )
    if validation_errors:
        return _failure(
            status="BLOCKED_OUTPUT",
            request_id=safe_request_id,
            generated_at=generated_at,
            error_code="OUTPUT_VALIDATION_FAILED:" + ",".join(validation_errors),
            error_message="本次解卦未通过内容核验，未作为完整结果发布。",
            request_sha256=request_sha256,
            question_sha256=question_sha256,
            chart_sha256=chart_sha256,
            prompt_sha256=prompt_sha256,
            provider_result=result,
            validation_errors=validation_errors,
        )

    return DirectReadingResponse(
        status="SUCCESS",
        direct_reading=DirectReadingContent(text=output_text, chart_facts=facts),
        audit=_empty_audit(
            request_id=safe_request_id,
            generated_at=generated_at,
            request_sha256=request_sha256,
            question_sha256=question_sha256,
            chart_sha256=chart_sha256,
            prompt_sha256=prompt_sha256,
            provider_result=result,
        ),
    ).model_dump(mode="json")


__all__ = [
    "CONTRACT_VERSION",
    "MAX_OUTPUT_TOKENS",
    "MODEL",
    "PROMPT_VERSION",
    "REASONING_EFFORT",
    "SYSTEM_PROMPT",
    "USER_TEMPLATE",
    "VERBOSITY",
    "DirectReadingProviderFailure",
    "DirectReadingProviderResult",
    "DirectReadingUsage",
    "OpenAIDirectReadingProvider",
    "build_direct_reading_prompts",
    "process_direct_reading_v2_request",
    "render_chart_packet",
    "validate_direct_reading_text",
]
